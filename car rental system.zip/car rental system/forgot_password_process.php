<?php
// Include database connection or any necessary files
require_once "config.php";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve username from form
    $username = $_POST['username'];

    // Generate a random password
    $new_password = bin2hex(random_bytes(8)); // Generate an 8-character random password

    // Hash the new password before storing it in the database
    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

    // Update the password in the database for the given username
    // Adjust the database table name and column names as per your database structure
    // Update the password in the database for the given username
    $stmt = $conn->prepare("UPDATE users SET password_hash = ? WHERE username = ?");
    if ($stmt === false) {
        // Check for errors
        die('Error preparing statement: ' . $conn->error);
    }

    // Bind parameters
    $stmt->bind_param("ss", $hashed_password, $username);

    // Execute the update query
    if ($stmt->execute()) {
        // Password updated successfully
        // You can also send the new password to the user via email here
        echo "Password reset successfully. New password: $new_password"; // Just for demonstration
    } else {
        // Error occurred while updating the password
        echo "Error updating password: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
}
?>
<p><a href="login.php">Back to Login</a></p>
