<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    // If not logged in, redirect to the login page
    header("Location: login.php");
    exit;
}

// Check if form data is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if all required fields are filled
    if (isset($_POST['name']) && isset($_POST['model']) && isset($_POST['year']) && isset($_POST['image']) && isset($_POST['description']) && isset($_POST['vehicle_id'])) {
        // Get form data
        $name = $_POST['name'];
        $model = $_POST['model'];
        $year = $_POST['year'];
        $image = $_POST['image'];
        $description = $_POST['description'];
        $vehicle_id = $_POST['vehicle_id'];

        // Establish database connection (replace with your credentials)
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "car rental system"; // Change to your actual database name

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Prepare update query
        $sql = "UPDATE vehicles SET name='$name', model='$model', year='$year', image='$image', description='$description' WHERE id='$vehicle_id'";

        if ($conn->query($sql) === TRUE) {
            // If update successful, redirect to manage-vehicles.php
            header("Location: manage-vehicles.php");
            exit;
        } else {
            echo "Error updating vehicle: " . $conn->error;
        }

        // Close the database connection
        $conn->close();
    } else {
        echo "All fields are required!";
    }
} else {
    // If form data is not submitted, redirect to manage-vehicles.php
    header("Location: manage-vehicles.php");
    exit;
}
?>
