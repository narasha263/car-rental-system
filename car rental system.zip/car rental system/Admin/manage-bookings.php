<?php include ('header.php'); ?>
<style>




.booking-item p {
    margin: 5px 0;
}

.btn {
    background-color: #007bff;
    color: #fff;
    border: none;
    padding: 8px 16px;
    border-radius: 5px;
    cursor: pointer;
}

.btn:hover {
    background-color: #0056b3;
}
</style>

<style>
.container {
    margin-top: 10px;
    text-align: center; 
    margin-left: 150px;
    margin-right: auto;
}

.booking-feedback {
    background-color: #f9f9f9;
    padding: 20px;
    border-radius: 10px;
    display: inline-block; /* Keep the content centered */
    text-align: left;
    margin-left: 60px; /* Add margin for spacing between booking feedback */
}

.booking-feedback p {
    margin: 5px 0;
}






</style>
<br>

<div class="container">
    <h1>PAYMENT DETAILS</h1>
    
    <?php
    // Establish database connection
    include_once 'db_connection.php';

    // Retrieve booking details
    $sql = "SELECT * FROM bookings";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $booking_id = $row["id"];
            $customer_name = $row["name"];
            $customer_email = $row["email"];
            $customer_phone = $row["phone"];
            $start_date = $row["start_date"];
            $end_date = $row["end_date"];
            $selected_vehicle_id = $row["selected_vehicle_id"];
            
            // Display booking details
            echo "<div class='booking-feedback'>";
            echo "<h2>Booking Details</h2>";
            echo "<p>Customer: $customer_name ($customer_email)</p>";
            echo "<p>Booking Dates: $start_date to $end_date</p>";
            echo "<p>Vehicle ID: $selected_vehicle_id</p>";
            echo "<form action='process_payment.php' method='post'>";
            echo "<input type='hidden' name='booking_id' value='$booking_id'>";
            echo "<input type='submit' class='btn' value='View Booking'>";
            echo "</form>";
            echo "</div>";
        }
    } else {
        echo "<p>No bookings found.</p>";
    }

    // Retrieve payment details
    $sql = "SELECT * FROM payments";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<div class='booking-feedback'>";
        echo "<h2>Payment Details</h2>";
        echo "<table border='1'>";
        echo "<tr><th>ID</th><th>Card Number</th><th>Expiry Date</th><th>CVV</th><th>Total Amount</th></tr>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row['id'] . "</td>";
            echo "<td>" . $row['card_number'] . "</td>";
            echo "<td>" . $row['expiry_date'] . "</td>";
            echo "<td>" . $row['cvv'] . "</td>";
            echo "<td>" . $row['total_amount'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        echo "</div>";
    } else {
        echo "<p>No payment details found.</p>";
    }

    // Close database connection
    $conn->close();
    ?>
</div>

<?php include "footer.php"; ?>
