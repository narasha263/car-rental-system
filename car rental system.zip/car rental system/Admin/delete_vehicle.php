<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    // If not logged in, redirect to the login page
    header("Location: login.php");
    exit;
}

// Check if vehicle ID is provided in the URL
if (!isset($_GET['vehicle_id'])) {
    // If not provided, redirect back to manage-vehicles.php
    header("Location: manage-vehicles.php");
    exit;
}

// Get the vehicle ID from the URL
$vehicle_id = $_GET['vehicle_id'];

// Establish database connection (replace with your credentials)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "car rental system"; // Change to your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare delete query
$sql = "DELETE FROM vehicles WHERE id = $vehicle_id";

if ($conn->query($sql) === TRUE) {
    // If delete successful, redirect to manage-vehicles.php
    header("Location: manage-vehicles.php");
    exit;
} else {
    echo "Error deleting vehicle: " . $conn->error;
}

// Close the database connection
$conn->close();
?>
