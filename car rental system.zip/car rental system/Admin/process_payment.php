<?php include ('header.php'); ?>

<style>
.container {
    margin-top: 50px;
    text-align: center; /* Center the content */
}

.payment-details {
    background-color: #f9f9f9;
    padding: 20px;
    border-radius: 10px;
    display: inline-block; /* Keep the content centered */
    text-align: left; /* Align text to the left within the payment-details div */
}

.payment-item {
    border: 1px solid #ccc;
    padding: 10px;
    margin-bottom: 20px;
}

.payment-item p {
    margin: 5px 0;
}

.btn {
    background-color: #007bff;
    color: #fff;
    border: none;
    padding: 8px 16px;
    border-radius: 5px;
    cursor: pointer;
}

.btn:hover {
    background-color: #0056b3;
}
</style>

<div class="container">
    <div class="payment-details">
        <h2>Payment Details</h2>
        <?php
        if(isset($_POST['booking_id'])) {
            $booking_id = $_POST['booking_id'];
            
            // Retrieve booking details from the database based on the provided booking ID
            // Replace the database connection details with your actual credentials
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "car rental system";
            
            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);
            
            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
            
            // Fetch booking details from the database
            $sql = "SELECT * FROM bookings WHERE id = $booking_id";
            $result = $conn->query($sql);
            
            if ($result->num_rows > 0) {
                // Output data of each row
                while($row = $result->fetch_assoc()) {
                    echo "<div class='payment-item'>";
                    echo "<p>Booking ID: " . $row["id"]. "</p>";
                    echo "<p>Customer Name: " . $row["name"]. "</p>";
                    echo "<p>Customer Email: " . $row["email"]. "</p>";
                    echo "<p>Start Date: " . $row["start_date"]. "</p>";
                    echo "<p>End Date: " . $row["end_date"]. "</p>";
                    echo "<p>Selected Vehicle ID: " . $row["selected_vehicle_id"]. "</p>";
                    // You can display more booking details as needed
                    echo "</div>";
                }
            } else {
                echo "No booking details found.";
            }
            $conn->close();
        } else {
            echo "No booking ID provided.";
        }
        ?>

           
        </form>
    </div>
</div>

<?php include ('footer.php'); ?>
