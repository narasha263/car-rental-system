<!-- Display the login form -->
<?php include ('header.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Car Rental Service</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: navy;
            color: black;
        }

        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 250px;
            background-color: #333;
            padding-top: 20px;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }

        .sidebar ul li {
            padding: 10px 15px;
            border-bottom: 1px solid #555;
        }

        .sidebar ul li a {
            color: #fff;
            text-decoration: none;
        }

        .content {
            margin-left: 250px;
            padding: 20px;
        }
    </style>
    <body>
    <div class="sidebar">
    <ul>
        <li><a href="#">Dashboard</a></li>
        <li><a href="manage-vehicles.php">Manage Vehicles</a></li>
        <li><a href="manage-bookings.php">Manage Bookings</a></li>
        <li><a href="users.php">Manage Users</a></li>
    </ul>
</div>
!-- Content Section -->
<div class="content">
    <!-- Banner Section -->
    <section id="banner">
        <div class="container text-center py-5">
            <h1>Manage Users</h1>
            <p class="lead">Add, edit, or delete Users.</p>
        </div>
    </section>

    <section id="user-management" class="bg-light py-5">
        <div class="container">
            <h2 class="text-center mb-4">Users Management</h2>
            <div class="row">
                
                
    <div class="content">
<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "car rental system";
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}// (Assuming connection code is already included here)

// Retrieve users from the database
$sql = "SELECT id, username FROM users";
$result = $conn->query($sql);
?>

</div>
<body>
    <div class="container">
        <h1>Manage Users</h1>
        <div class="row">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Add New User</h5>
                        <form action="add_user.php" method="post">
                            <!-- Add fields for adding a new user if needed -->
                            <button type="submit" class="btn btn-primary">Add User</button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-8">
                <h2>Users List</h2>
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Username</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($result->num_rows > 0) {
                            // Output data of each row
                            while($row = $result->fetch_assoc()) {
                                echo "<tr>";
                                echo "<td>" . $row["id"] . "</td>";
                                echo "<td>" . $row["username"] . "</td>";
                                echo "<td>";
                                echo "<a href='edit_user.php?id=" . $row["id"] . "' class='btn btn-primary'>Edit</a>";
                                echo "<a href='delete_user.php?id=" . $row["id"] . "' class='btn btn-danger'>Delete</a>";
                                echo "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='3'>No users found</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>