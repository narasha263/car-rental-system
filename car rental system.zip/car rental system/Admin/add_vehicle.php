<?php
// Include database connection
include 'db_connection.php';

// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    // If not logged in, redirect to the login page
    header("Location: login.php");
    exit;
}
// Define variables and initialize with empty values
$name = $model = $year = $image = $description = "";
$name_err = $model_err = $year_err = $image_err = $description_err = "";

// Processing form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate name
    if (isset($_POST["name"]) && !empty(trim($_POST["name"]))) {
        $name = trim($_POST["name"]);
    } else {
        $name_err = "Please enter the name of the vehicle.";
    }

    // Validate model
    if (isset($_POST["model"]) && !empty(trim($_POST["model"]))) {
        $model = trim($_POST["model"]);
    } else {
        $model_err = "Please enter the model of the vehicle.";
    }

    // Validate year
    if (isset($_POST["year"]) && !empty(trim($_POST["year"])) && is_numeric(trim($_POST["year"]))) {
        $year = trim($_POST["year"]);
    } else {
        $year_err = "Please enter a valid year.";
    }

    // Validate image
    if (isset($_POST["image"]) && !empty(trim($_POST["image"]))) {
        $image = trim($_POST["image"]);
    } else {
        $image_err = "Please enter the image URL.";
    }

    // Validate description
    if (isset($_POST["description"]) && !empty(trim($_POST["description"]))) {
        $description = trim($_POST["description"]);
    } else {
        $description_err = "Please enter a description for the vehicle.";
    }

    // Check input errors before inserting into database
    if (empty($name_err) && empty($model_err) && empty($year_err) && empty($image_err) && empty($description_err)) {
        // Prepare an insert statement
        $sql = "INSERT INTO vehicles (name, model, year, image, description) VALUES (?, ?, ?, ?, ?)";

        if ($stmt = $conn->prepare($sql)) {
            // Bind variables to the prepared statement as parameters
            $stmt->bind_param("ssiss", $param_name, $param_model, $param_year, $param_image, $param_description);

            // Set parameters
            $param_name = $name;
            $param_model = $model;
            $param_year = $year;
            $param_image = $image;
            $param_description = $description;

            // Attempt to execute the prepared statement
            if ($stmt->execute()) {
                // Redirect to manage-vehicles.php
                header("location: manage-vehicles.php");
                exit;
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            $stmt->close();
        }
    }
}

?>
<?php


// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    // If not logged in, redirect to the login page
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Car Rental Service</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: navy;
            color: black;
        }

        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 250px;
            background-color: #333;
            padding-top: 20px;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }

        .sidebar ul li {
            padding: 10px 15px;
            border-bottom: 1px solid #555;
        }

        .sidebar ul li a {
            color: #fff;
            text-decoration: none;
        }

        .content {
            margin-left: 250px;
            padding: 20px;
        }
    </style>
</head>
<body>

<!-- Navbar Section -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">Car Rental Admin</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="#">Profile</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Sidebar Section -->
<div class="sidebar">
    <ul>
        <li><a href="#">Dashboard</a></li>
        <li><a href="manage-vehicles.php">Manage Vehicles</a></li>
        <li><a href="manage-bookings.php">Manage Bookings</a></li>
        <li><a href="users.php">Manage Users</a></li>
    </ul>
</div>

<!-- Content Section -->
<div class="content">
    <!-- Banner Section -->
    <section id="banner">
        <div class="container text-center py-5">
            <h1>Manage Vehicles</h1>
            <p class="lead">Add new vehicles to the rental options.</p>
        </div>
    </section>

    <!-- Add New Vehicle Form -->
    <section id="add-vehicle-form" class="bg-light py-5">
        <div class="container">
            <h2 class="text-center mb-4">Add New Vehicle</h2>
            <div class="row">
                <div class="col-md-6 offset-md-3">
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="mb-3">
                            <label for="name" class="form-label">Name</label>
                            <input type="text" class="form-control" id="name" name="name">
                        </div>
                        <div class="mb-3">
                            <label for="model" class="form-label">Model</label>
                            <input type="text" class="form-control" id="model" name="model">
                        </div>
                        <div class="mb-3">
                            <label for="year" class="form-label">Year</label>
                            <input type="number" class="form-control" id="year" name="year">
                        </div>
                        <div class="mb-3">
                            <label for="image" class="form-label">Image URL</label>
                            <input type="text" class="form-control" id="image" name="image">
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Add Vehicle</button>
                    </form>
                </div>
            </div>
        </div>
    </section>
</div>

<!-- Bootstrap JS and dependencies -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>
</html>

