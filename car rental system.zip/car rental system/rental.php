<?php include ('header.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Rent Vehicle - Car Rental Service</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: navy;
      color: black;
      /* Assuming you have a background image */
      background-image: url('images/bg.jpg');
    }
    
    .container {
      background-color: rgb(30, 69, 177);
      padding: 20px;
      margin-top: 50px;
    }
  </style>
</head>
<body>

<!-- Rental Form Section -->
<section id="rental-form">
  <div class="container">
    <h2 class="text-center mb-4">Rent Vehicle</h2>
    <?php
    // Check if the image_id parameter is set in the URL
    if (isset($_GET['image_id'])) {
        // Retrieve the image_id from the URL
        $image_id = $_GET['image_id'];

        // Sample array of rental options (replace this with your actual data retrieval logic)
        $vehicles = [
            ["id" => 3, "name" => "Ford", "model" => "Explorer", "year" => 2021, "image" => "images/explorer.jpg", "description" => "SUV with ample cargo space and advanced safety features.", "price" => 50],
            ["id" => 1, "name" => "Toyota", "model" => "Camry", "year" => 2022, "image" => "images/toyota camry.jpg", "description" => "Spacious sedan with comfortable seating for five.", "price" => 40],
            ["id" => 5, "name" => "Isuzu", "model" => "D-Max", "year" => 2023, "image" => "images/isuzu.jpg", "description" => "Robust pickup truck suitable for heavy-duty tasks.", "price" => 60],
            ["id" => 2, "name" => "Honda", "model" => "Civic", "year" => 2023, "image" => "images/civic.jpg", "description" => "Sporty sedan perfect for city driving.", "price" => 45],
            ["id" => 4, "name" => "Toyota", "model" => "Land Cruiser", "year" => 2022, "image" => "images/land cruiser.jpg", "description" => "Powerful SUV capable of handling rough terrain with ease.", "price" => 70],
            ["id" => 6, "name" => "Nissan", "model" => "Patrol", "year" => 2021, "image" => "images/nissan.jpg", "description" => "Luxurious SUV with spacious interiors and advanced technology features.", "price" => 80],
          ];

        // Search for the vehicle with the given image_id
        $vehicle = array_filter($vehicles, function ($v) use ($image_id) {
            return $v['id'] == $image_id;
        });

        // If the vehicle is found, display the rental form
        if (!empty($vehicle)) {
            // Get the first (and only) element from the filtered array
            $vehicle = reset($vehicle);
            ?>
            <div class="card">
                <img src="<?php echo $vehicle['image']; ?>" class="card-img-top" alt="<?php echo $vehicle['name']; ?>">
                <div class="card-body">
                    <h5 class="card-title"><?php echo $vehicle['name'] . ' ' . $vehicle['model']; ?></h5>
                    <p class="card-text"><?php echo $vehicle['description']; ?></p>
                    <p class="card-text">Price: $<?php echo $vehicle['price']; ?> per day</p>
                    <!-- Include your rental form here -->
                    <form action="rent_process.php" method="post">
                        <!-- Hidden input to pass the image_id -->
                        <input type="hidden" name="image_id" value="<?php echo $vehicle['id']; ?>">
                        <!-- Add more form fields as needed -->
                        <div class="mb-3">
                        <label for="name" class="form-label">Full Name</label>
                <input type="text" class="form-control" id="name" name="name" required>
              </div>
              <div class="mb-3">
                <label for="email" class="form-label">Email Address</label>
                <input type="email" class="form-control" id="email" name="email" required>
              </div>
              <div class="mb-3">
                <label for="phone" class="form-label">Phone Number</label>
                <input type="tel" class="form-control" id="phone" name="phone" required>
              </div>
              <div class="mb-3">
              <div class="mb-3">
                            <label for="national_id" class="form-label">National ID</label>
                            <input type="file" class="form-control" id="national_id_path" name="national_id" required>
                        </div>
                        <div class="mb-3">
                            <label for="photo" class="form-label">Photo</label>
                            <input type="file" class="form-control" id="photo_path" name="photo" required>
                        </div>

                            <label for="start_date" class="form-label">Start Date</label>
                            <input type="date" class="form-control" id="start_date" name="start_date" required>
                        </div>
                        <div class="mb-3">
                            <label for="end_date" class="form-label">End Date</label>
                            <input type="date" class="form-control" id="end_date" name="end_date" required>
                        </div>
                        <input type="hidden" name="selected_vehicle_id" value="<?php echo $imageId; ?>">

                        <button type="submit" class="btn btn-primary">Rent Now</button>
                    </form>
                </div>
            </div>
            <?php
        } else {
            // Display error message if the vehicle is not found
            echo '<p class="text-danger">Vehicle not found.</p>';
        }
    } else {
        // Display error message if image_id parameter is not set in the URL
        echo '<p class="text-danger">Image ID not provided.</p>';
    }
    ?>
  </div>
</section>

<!-- Bootstrap JS and dependencies -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>
</html>
