<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Our Services - Car Rental Service</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: navy;
      color: black;
    }
  </style>
</head>
<body>
<!-- Navigation Section -->
<?php include 'header.php'; ?>

<!-- Our Services Section -->
<section id="services" class="py-5">
  <div class="container text-center">
    <h2>Our Services</h2>
    <p>We offer a wide range of car rental services to cater to your needs.</p>
    <ul>
      <li>Daily Rentals</li>
      <li>Weekly Rentals</li>
      <li>Monthly Rentals</li>
      <li>Airport Pickup and Drop-off</li>
      <li>24/7 Customer Support</li>
    </ul>
  </div>
</section>

<!-- Footer Section -->
<?php include 'footer.php'; ?>

<!-- Bootstrap JS and dependencies -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>
</html>
