<?php include_once 'header.php'; ?>

<?php
include_once 'db_connection.php'; // Assuming you have a file named db_connection.php where you establish a database connection

// Check if form data is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $startDate = $_POST['start_date'];
    $endDate = $_POST['end_date'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $selectedVehicleId = $_POST['selected_vehicle_id'];
    $_POST['image_id'];
    $selected_vehicle_id = $_POST['selected_vehicle_id'];


    // File upload paths
    $national_id_path = ''; // Placeholder for the path to the uploaded National ID file
    $photo_path = ''; // Placeholder for the path to the uploaded photo file

    // Handle file uploads for National ID
    if (isset($_FILES['national_id_path']) && $_FILES['national_id_path']['error'] === UPLOAD_ERR_OK) {
      $uploadDir = 'uploads/'; // Directory to store uploaded files
      $nationalIdName = $_FILES['national_id_path']['name'];
      $national_id_path = $uploadDir . $nationalIdName;
      move_uploaded_file($_FILES['national_id_path']['tmp_name'], $nationalIdPath);
  }

  // Handle file uploads for photo
  if (isset($_FILES['photo_path']) && $_FILES['photo_path']['error'] === UPLOAD_ERR_OK) {
      $uploadDir = 'uploads/'; // Directory to store uploaded files
      $photoName = $_FILES['photo_path']['name'];
      $photo_path = $uploadDir . $photoName;
      move_uploaded_file($_FILES['photo_path']['tmp_name'], $photo_path);
  }


  $sql = "INSERT INTO bookings (name, email, phone, start_date, end_date, selected_vehicle_id, national_id_path, photo_path) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
  $stmt = $conn->prepare($sql);

  $stmt->bind_param("ssssssss", $name, $email, $phone, $start_date, $end_date, $selected_vehicle_id, $national_id_path, $photo_path);
    
    // Execute the prepared statement
    if ($stmt->execute()) {
        // Booking successfully inserted into database
        $confirmationMessage = "Your booking has been confirmed.";
    } else {
        // Error occurred while inserting into database
        $confirmationMessage = "Sorry, there was an error processing your booking. Please try again later.";
    }

    // Close statement
    $stmt->close();
} else {
    // Redirect to homepage if accessed directly without submitting form
    header("Location: index.php");
    exit();
}
    // Display confirmation message
    $confirmationMessage = "Thank you, $name! Your booking for the selected vehicle has been confirmed from $startDate to $endDate.Go to the payment page below";

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Booking Confirmation</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    /* Add custom CSS styles here */
  </style>
</head>
<body>

<!-- Confirmation Section -->
<section id="confirmation" class="bg-light py-5">
  <div class="container">
    <h2 class="text-center mb-4">Booking Confirmation</h2>
    <div class="row">
      <div class="col-md-6 offset-md-3">
        <div class="card">
          <div class="card-body">
            <?php if (isset($confirmationMessage)) : ?>
              <p><?php echo $confirmationMessage; ?></p>
            <?php else : ?>
              <p>Sorry, there was an error processing your booking. Please try again later.</p>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<p class='text-center'><a href='order.php' class='btn btn-primary'>Payment Page</a></p>
<p class='text-center'><a href='index.php' class='btn btn-primary'>Back to Home</a></p>


<?php include 'footer.php'; ?>

<!-- Bootstrap JS and dependencies -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>

</body>
</html>
