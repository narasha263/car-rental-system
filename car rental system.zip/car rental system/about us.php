<?php include_once 'header.php'?>
<section id="about" class="py-5">
  <div class="container">
    <h2 class="text-center mb-4">About Us</h2>
    <div class="row">
      <div class="col-lg-6">
        <h3>Who We Are</h3>
        <p>We are a leading car rental service committed to providing quality vehicles and excellent customer service.</p>
      </div>
      <div class="col-lg-6">
        <h3>Why Choose Us</h3>
        <ul>
          <li>Wide selection of vehicles</li>
          <li>Competitive prices</li>
          <li>Convenient booking process</li>
          <li>24/7 customer support</li>
        </ul>
      </div>
    </div>
  </div>
</section>
<?php include_once 'footer.php'?>
