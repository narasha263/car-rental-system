<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About Us - Car Rental Service</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: navy;
      color: black;
    }
  </style>
</head>
<body>
<!-- Navigation Section -->
<?php include 'header.php'; ?>

<!-- About Us Section -->
<section id="about" class="py-5">
  <div class="container text-center">
    <h2>About Us</h2>
    <p>Welcome to Car Rental Service, where we strive to provide you with the best car rental experience.</p>
    <p>Our mission is to offer hassle-free and affordable car rental solutions to our customers.</p>
  </div>
</section>

<!-- Footer Section -->
<?php include 'footer.php'; ?>

<!-- Bootstrap JS and dependencies -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>
</html>
