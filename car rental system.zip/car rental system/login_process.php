<?php
// Include your database connection file
include_once 'db_connection.php';

// Check if the form is submitted via POST method
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if both username and password are provided
    if (isset($_POST["username"]) && isset($_POST["password"])) {
        // Retrieve username and password from the form
        $username = $_POST["username"];
        $password = $_POST["password"];

        // Prepare a SQL statement to retrieve the hashed password for the provided username
        $stmt = $conn->prepare("SELECT id, username, password_hash FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if the username exists in the database
        if ($result->num_rows == 1) {
            // Fetch the row
            $row = $result->fetch_assoc();
            $stored_password_hash = $row['password_hash'];

            // Verify the provided password with the stored hashed password
            if (password_verify($password, $stored_password_hash)) {
                // Start the session and set the logged_in session variable
                session_start();
                $_SESSION["logged_in"] = true;
                $_SESSION["user_id"] = $row['id'];

                // Redirect the user to the homepage or dashboard
                header("Location: index.php");
                exit();
            } else {
                // Password is incorrect, redirect back to the login page with an error message
                header("Location: login.php?error=invalid_credentials");
                exit();
            }
        } else {
            // Username doesn't exist, redirect back to the login page with an error message
            header("Location: login.php?error=invalid_credentials");
            exit();
        }
    } else {
        // Username or password is missing, redirect back to the login page with an error message
        header("Location: login.php?error=missing_credentials");
        exit();
    }
} else {
    // If the form is not submitted via POST method, redirect back to the login page
    header("Location: login.php");
    exit();
}

// Close the database connection
$stmt->close();
$conn->close();
?>
