<?php include_once 'header.php'?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Forgot Password</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
  {
    background: navy;
      color: black;
    background-image:('images/bg.jpg');
}   
</style>
</head>
<body>

<!-- Navigation Section -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <!-- Your navigation code here -->
</nav>

<!-- Forgot Password Form -->
<section id="forgot-password" class="py-5">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-6">
        <div class="card">
          <div class="card-body">
            <h2 class="text-center mb-4">Forgot Password</h2>
            <form action="forgot_password_process.php" method="post">
              <div class="mb-3">
                <label for="username" class="form-label">Enter Your Username:</label>
                <input type="text" class="form-control" id="username" name="username" required>
              </div>
              <button type="submit" class="btn btn-primary btn-lg btn-block">Reset Password</button>
            </form>
            <p class="text-center mt-3"><a href="login.php">Back to Login</a></p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<?php include_once 'footer.php'?>
<!-- Bootstrap JS and dependencies -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>
</html>
