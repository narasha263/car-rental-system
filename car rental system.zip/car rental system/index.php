
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Car Rental Service</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
body{
    background: navy;
      color: black;
    background-image:('images/bg.jpg');
}  </style>
</head>
<body>

<!-- Navigation Section -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container">
    <a class="navbar-brand" href="#">Car Rental Service</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about.php">About Us</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="services.php">Our Services</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="explore_rental.php">Rental Options</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="login.php">Sign In</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="register.php">Sign Up</a>
        </li>
             <li class="nav-item">
          <a class="nav-link" href="Admin/login.php">Admin</a>
        </li>
        <li class="nav-item">
        <a class="nav-link" href="cart.php">View Cart</a>
    </li>
      </ul>
    </div>
  </div>
</nav>

<!-- Banner Section -->
<section id="banner">
  <div class="container text-center py-5">
    <h1>Welcome to Car Rental Service</h1>
    <p class="lead">Discover the joy of hassle-free car rentals!</p>
    <a href="explore_rental.php" class="btn btn-primary btn-lg">Explore Rental Options</a>
  </div>
</section>

<!-- Featured Vehicles Section -->
<section id="featured-vehicles" class="bg-light py-5">
  <div class="container">
    <h2 class="text-center mb-4">Featured Vehicles</h2>
    <div class="row">
      <?php
      // Define an array of vehicles with their details
      $vehicles = [
        ["id" => 1, "name" => "Commercial Car", "image" => "images/commercial car.jpg", "description" => "good for commercial work and business"],
        ["id" => 2, "name" => "Isuzu D-max", "image" => "images/isuzu.jpg", "description" => "Robust pickup truck suitable for heavy-duty tasks"],
        ["id" => 3, "name" => "Toyota Camry", "image" => "images/toyota camry.jpg", "description" => "Spacious sedan with comfortable seating for five."]
      ];

      // Loop through the array to generate HTML for each vehicle
      foreach ($vehicles as $vehicle) {
        ?>
        <div class="col-md-4">
          <div class="card">
            <img src="<?php echo $vehicle['image']; ?>" class="card-img-top" alt="<?php echo $vehicle['name']; ?>">
            <div class="card-body">
              <h5 class="card-title"><?php echo $vehicle['name']; ?></h5>
              <p class="card-text"><?php echo $vehicle['description']; ?></p>
              <!-- Update the link to pass the image ID as a parameter -->
              <a href="rent.php?image_id=<?php echo $vehicle['id']; ?>" class="btn btn-primary">Rent Now</a>
            </div>
          </div>
        </div>
        <?php
      }
      ?>
    </div>
  </div>
</section>



<!-- Call to Action Section -->
<section id="cta" class="bg-primary text-white py-5">
  <div class="container text-center">
    <h2 class="mb-4">Start Your Journey Today</h2>
    <p class="mb-4">Explore our wide range of vehicles and book your next adventure.</p>
    <a href="#" class="btn btn-light btn-lg">Rent Now</a>
  </div>
</section>

<!-- Footer Section -->
<footer class="bg-dark text-white py-4">
  <div class="container text-center">
    <p>&copy; 2024 Car Rental Service. All rights reserved.</p>
  </div>
</footer>

<!-- Bootstrap JS and dependencies -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>
</html>
