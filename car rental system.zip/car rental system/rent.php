<?php include_once 'header.php'; ?>

<?php
// Define an array of vehicles with their details
$vehicles = [
    1 => ["name" => "Commercial Car", "image" => "images/commercial car.jpg", "description" => "good for commercial work and business","price" => 50],
    2 => ["name" => "Isuzu D-max", "image" => "images/isuzu.jpg", "description" => "Robust pickup truck suitable for heavy-duty tasks","price" => 50],
    3 => ["name" => "Toyota Camry", "image" => "images/toyota camry.jpg", "description" => "Spacious sedan with comfortable seating for five.","price" => 50]
];

// Check if the image ID is set in the URL parameters
if (isset($_GET['image_id'])) {
    // Get the image ID from the URL parameters
    $imageId = $_GET['image_id'];

    // Check if the image ID exists in the vehicles array
    if (isset($vehicles[$imageId])) {
        // Get the details of the selected vehicle
        $selectedVehicle = $vehicles[$imageId];
    } else {
        // Handle invalid image ID
        $selectedVehicle = ["name" => "Unknown Vehicle", "image" => "images/default.jpg", "description" => "Description not available"];
    }
} else {
    // Handle case when no image ID is provided
    $selectedVehicle = ["name" => "Unknown Vehicle", "image" => "images/default.jpg", "description" => "Description not available"];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Selected Vehicle</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    /* Add custom CSS styles here */
  </style>
</head>
<body>

<!-- Selected Vehicle Section -->
<section id="selected-vehicle" class="bg-light py-5">
  <div class="container">
    <h2 class="text-center mb-4">Selected Vehicle</h2>
    <div class="row">
      <div class="col-md-6 offset-md-3">
        <div class="card">
          <!-- Use PHP to set the src attribute dynamically -->
          <img src="<?php echo $selectedVehicle['image']; ?>" class="card-img-top" alt="Selected Vehicle">
          <div class="card-body">
            <h5 class="card-title"><?php echo $selectedVehicle['name']; ?></h5>
            <p class="card-text"><?php echo $selectedVehicle['description']; ?></p>
            <!-- Add rental form or booking details here -->
            <form action="booking_confirmation.php" method="POST">
              <!-- Include input fields for user details, rental dates, etc. -->
              <!-- Example: -->
              <div class="mb-3">
                <label for="name" class="form-label">Full Name</label>
                <input type="text" class="form-control" id="name" name="name" required>
              </div>
              <div class="mb-3">
                <label for="email" class="form-label">Email Address</label>
                <input type="email" class="form-control" id="email" name="email" required>
              </div>
              <div class="mb-3">
                <label for="phone" class="form-label">Phone Number</label>
                <input type="tel" class="form-control" id="phone" name="phone" required>
              </div>
              <div class="mb-3">
                            <label for="national_id" class="form-label">National ID</label>
                            <input type="file" class="form-control" id="national_id" name="national_id" required>
                        </div>
                        <div class="mb-3">
                            <label for="photo" class="form-label">Photo</label>
                            <input type="file" class="form-control" id="photo" name="photo" required>
                        </div>
              <div class="mb-3">
                <label for="start_date" class="form-label">Start Date</label>
                <input type="date" class="form-control" id="start_date" name="start_date" required>
              </div>
              <div class="mb-3">
                <label for="end_date" class="form-label">End Date</label>
                <input type="date" class="form-control" id="end_date" name="end_date" required>
              </div>
              <input type="hidden" name="selected_vehicle_id" value="<?php echo $imageId; ?>">
              <button type="submit" class="btn btn-primary">Confirm Booking</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<?php include 'footer.php'; ?>

<!-- Bootstrap JS and dependencies -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
<script>
  // Get today's date
  var today = new Date().toISOString().split('T')[0];

  // Set the minimum value for the date input fields
  document.getElementById("start_date").setAttribute("min", today);
  document.getElementById("end_date").setAttribute("min", today);
</script>
</body>
</html>
